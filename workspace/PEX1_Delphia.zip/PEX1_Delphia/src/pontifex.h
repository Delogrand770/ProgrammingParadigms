/*
 * File:   pontifex.h
 * Author: YOUR_NAME_HERE
 *
 * Description: Declarations of methods used to implement the Pontifex encryption scheme.
 *              http://www.schneier.com/solitaire.html
 */

#ifndef PONTIFEX_H_
#define PONTIFEX_H_

#define ALPHABET_SIZE 26  // This could be changed if used with a different language/alphabet.

// YOUR PONTIFEX FUNCTION PROTOTYPES GO HERE

#endif /* PONTIFEX_H_ */
