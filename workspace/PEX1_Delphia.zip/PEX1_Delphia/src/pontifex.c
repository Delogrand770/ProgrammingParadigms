/*
 * File:   pontifex.c
 * Author: YOUR_NAME_HERE
 *
 * Description: Definitions of methods used to implement the Pontifex encryption scheme.
 *              http://www.schneier.com/solitaire.html
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "deck.h"
#include "files.h"
#include "pontifex.h"

// YOUR PONTIFEX FUNCTION DEFINITIONS GO HERE
